# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.11.1'
__hash__ = '39c17457bae91baf8fe710dc989791e45879f136'
__date__ = '20190620'
